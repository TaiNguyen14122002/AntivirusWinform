// harmless code: no execution required
