This is a harmless ZIP path test.
