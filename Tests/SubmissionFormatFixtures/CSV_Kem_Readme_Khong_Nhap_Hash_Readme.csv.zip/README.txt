Tệp hướng dẫn an toàn — KHÔNG phải mẫu mã độc, không nhập hash vào VirusSignatures.
